package com.jemersoft.pokeapi.model;

import java.util.List;

public class FlavorTextEntriesGroup {
    private List<FlavorTextEntries> flavor_text_entries;

    public List<FlavorTextEntries> getFlavor_text_entries() {
        return flavor_text_entries;
    }

    public void setFlavor_text_entries(List<FlavorTextEntries> flavor_text_entries) {
        this.flavor_text_entries = flavor_text_entries;
    }

}
