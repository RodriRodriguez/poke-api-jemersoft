package com.jemersoft.pokeapi.model;

public class Flavor {
}
